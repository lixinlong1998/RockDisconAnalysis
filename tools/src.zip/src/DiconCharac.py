import struct
import math
import time
import multiprocessing
import laspy
from itertools import combinations
import os
import pickle
from collections import defaultdict
import alphashape
import numpy as np
from shapely.geometry import Point, Polygon
import pyvista as pv
from scipy.spatial import ConvexHull, Delaunay
from src import Cluster
from src import Discontinuity
from src import PointCloud
from src import Rockblock
from tqdm import tqdm


def discontinuity_characterization(discontinuity: Discontinuity.Discontinuity):
    '''
    调用discontinuity类的方法以计算特征参数
    :param discontinuity:
    :return:
    '''

    # 预设定参数
    edge_method = 'convex'  # 'ashape' or 'convex'
    trace_method = 'edges'  # 'farthest2' or 'edges'
    disc_type = 'elliptical'  # 'elliptical' or 'circle'
    roughness_method = 'pca'  # 'zrange' or 'pca'

    start_time = time.perf_counter()
    # 寻找cluster点云的平面边界，注意如果只是为了寻找迹线，则直接计算凸包即可，因为凹点不可能成为迹线的端点
    # [每一步都需要检验discontinuity是否valid]
    if not discontinuity.valid:
        return discontinuity
    if edge_method == 'convex':
        discontinuity.get_convexhull()
    elif edge_method == 'ashape':
        discontinuity.get_alpha_shape()
    else:
        discontinuity.get_convexhull()
        discontinuity.get_alpha_shape()

    # 提取迹线线段,默认迹线求解方法为farthest2
    # [每一步都需要检验discontinuity是否valid]
    if not discontinuity.valid:
        return discontinuity
    if trace_method == 'edges':
        discontinuity.get_trace_segment_from_edges()
    elif trace_method == 'farthest2':
        discontinuity.get_trace_segment_from_farthest2()
    else:
        discontinuity.get_trace_segment_from_farthest2()

    # 计算迹线长度
    discontinuity.get_trace_length()
    # [每一步都需要检验discontinuity是否valid]
    if not discontinuity.valid:
        return discontinuity

    # 计算结构面粗糙度
    if roughness_method == 'pca':
        discontinuity.get_roughness(method='pca')
    elif roughness_method == 'zrange':
        discontinuity.get_roughness(method='zrange')

    # 计算结构面圆盘模型
    if disc_type == 'circle':
        discontinuity.get_disc_circle()
    elif disc_type == 'elliptical':
        discontinuity.get_disc_elliptical()

    # 计算开销
    discontinuity.calculate_time = time.perf_counter() - start_time

    return discontinuity


def print_error(value):
    '''
    这个函数可以输出多进程中的报错，但是不会终止多进程
    '''
    print("error: ", value)


def multiprocess_discontinuity_characterization(discontinuitys, pool_size):
    '''
    multiprocess_
    :param discontinuitys:
    :return:
    '''
    starttime = time.perf_counter()
    # creat multiprocessing pool with given process number
    pool = multiprocessing.Pool(processes=pool_size)

    # Divide discontinuitys into groups by pool_size.
    # 原始的discontinuity是按照点的数量进行从大到小排序的，此处需要根据discontinuity的points的数量进行均匀分配
    # 使用“轮流分配”的策略（round-robin），把排序后的 datalist 依次分发到不同的 batch 容器中
    datalist = discontinuitys.discontinuitys
    # 按点数量从大到小排序
    datalist_ranked = sorted(datalist, key=lambda d: len(d.rock_points.points), reverse=True)
    # 初始化 pool_size 个空 batch
    batches = [[] for _ in range(pool_size)]
    # 轮流将数据项依次分配到各 batch 中，确保每个 batch 的数据点数量尽量均衡
    for idx, item in enumerate(datalist_ranked):
        batches[idx % pool_size].append(item)
    batch_size = math.ceil(np.mean([len(batch) for batch in batches]))
    print('pool_size:', pool_size)
    print('batch_size:', batch_size)
    print('batch_number:', len(batches))

    # For each batch, a process pool is started
    results = []
    for batch in batches:
        result = pool.starmap_async(discontinuity_characterization, [(discontinuity,) for discontinuity in batch],
                                    error_callback=print_error)
        results.append(result)

    # Wait for all process pools to finish executing
    print('Waiting for all subprocesses done...')
    for result in results:
        result.wait()

    # 获取所有子进程返回的结果（二维列表），再拉平成一维
    true_results = [r.get() for r in results]  # => List of List
    flattened = [item for sublist in true_results for item in sublist]
    discontinuitys.discontinuitys = flattened  # 可选：更新结构体
    assert len(discontinuitys.discontinuitys) == len(flattened), "长度不一致，可能处理有误"

    # Closing the process pool
    pool.close()
    pool.join()
    print(
        f'[time cost]{format_seconds(time.perf_counter() - starttime)} — calculate characterization of discontinuitys.')
    return discontinuitys


def multiprocess_discontinuity_characterization_test(discontinuitys, pool_size):
    starttime = time.perf_counter()

    datalist = discontinuitys.discontinuitys
    total = len(datalist)

    with multiprocessing.Pool(processes=pool_size) as pool:
        # 用 imap_unordered 提供实时进度反馈
        results = []
        for result in tqdm(pool.imap_unordered(discontinuity_characterization, datalist), total=total,
                           desc="Processing discontinuities"):
            results.append(result)

    print(
        f'[time cost]{format_seconds(time.perf_counter() - starttime)} — calculate characterization of discontinuitys.')
    return discontinuitys


def format_seconds(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h} h {m} min {s:.2f} sec"
