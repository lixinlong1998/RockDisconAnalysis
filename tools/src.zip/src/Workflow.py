import struct
import math
import time
import multiprocessing
import laspy
from itertools import combinations
import os
import pickle
from collections import defaultdict
import alphashape
import numpy as np
from shapely.geometry import Point, Polygon
import pyvista as pv
from scipy.spatial import ConvexHull, Delaunay
from src import Cluster
from src import Discontinuity
from src import PointCloud
from src import Rockblock
from tqdm import tqdm


#####################################################################################
#####################################################################################
#####################################################################################
def load_pointcloud(data_path):
    '''
    :param data_path: 文件路径，tab分隔、无表头
    :return: X, Y, Z, js, cl, A, B, C, D（为张量化字段），rock_pointcloud 对象
    '''
    starttime = time.perf_counter()
    # 读取数据（无表头，tab 分隔）
    data = np.loadtxt(data_path, delimiter='\t')

    # 提取所有 (js, cl) 并生成唯一 cluster_id
    js_cl_list = [(int(row[3]), int(row[4])) for row in data]
    unique_clusters = list(set(js_cl_list))
    cluster_id_dict = {key: idx for idx, key in enumerate(unique_clusters)}
    clusters_pointcloud = {key: PointCloud.RockPointCloud() for idx, key in enumerate(unique_clusters)}

    total_pointcloud = PointCloud.RockPointCloud()
    for point_id, row in enumerate(data):
        X, Y, Z = row[0:3]
        joint_id = int(row[3])
        joint_cluster_id = int(row[4])
        cluster_id = cluster_id_dict[(joint_id, joint_cluster_id)]
        R, G, B = 0, 0, 0
        a, b, c, d = row[5:9]

        total_pointcloud.add(X, Y, Z, point_id, joint_id, joint_cluster_id, cluster_id, R, G, B, a, b, c, d)

    # 提取感兴趣字段用于张量化处理
    print(f'[time cost]{format_seconds(time.perf_counter() - starttime)} — load point cloud to total_pointcloud.')
    return data, total_pointcloud, clusters_pointcloud, cluster_id_dict


def get_clusters_pointcloud(data, total_pointcloud, clusters_pointcloud):
    """
    Returns
    cluster_pointcloud : dict{(int, int):PointCloud.RockPointCloud()}
        键为 (js, cl)，值为cluster对应的点云。
    """
    starttime = time.perf_counter()
    # 直接对 data 每行循环
    for point_idx, row in enumerate(data):
        js = int(row[3])  # 第 4 列
        cl = int(row[4])  # 第 5 列
        clusters_pointcloud[(js, cl)].append(total_pointcloud.points[point_idx])
    print(f'[time cost]{format_seconds(time.perf_counter() - starttime)} — create point cloud set for clusters.')
    return clusters_pointcloud


def get_clusters(clusters_pointcloud, cluster_id_dict):
    starttime = time.perf_counter()
    clusters = Cluster.Clusters()
    for key, cluster_id in cluster_id_dict.items():
        rock_points = clusters_pointcloud[key]
        a_point = rock_points.points[0]
        plane_params = a_point.plane_paras
        clusters.add(key[0], key[1], cluster_id, rock_points, plane_params)
    print(f'[time cost]{format_seconds(time.perf_counter() - starttime)} — create clusters from clusters_pointcloud.')
    return clusters


def get_discontinuitys(clusters):
    def npget_dip_dir(np_clusters_normal):
        '''
        'npget' means using numpy tensor to facilitate the process.

        :param np_clusters_planeparas: numpy array with shape: (N, 3)，归一化后的A_nol, B_nol, C_nol
        :return: dip_direction, direction: numpy array with shape: (N, 2)，倾角、倾向
        '''
        a = np_clusters_normal[:, 0]
        b = np_clusters_normal[:, 1]
        c = np_clusters_normal[:, 2]
        # D：是平面与原点位置关系有关的偏移量，不影响方向，因此不参与单位化

        # 倾角 dip = arccos(|c|)，单位为度
        dips = np.degrees(np.arccos(np.abs(c)))  # 结果范围：[0, 90]

        # 倾向 strike = atan2(-b, a)，结果范围 [0, 360)
        strikes = np.degrees(np.arctan2(-b, a))
        strikes = np.where(strikes < 0, strikes + 360, strikes)

        # 输出 shape 校验（可选）
        print('A_nor.shape:', a.shape)
        print('dips.shape:', dips.shape)

        # 合并输出
        dip_dir = np.stack([dips, strikes], axis=1)  # (N, 2)
        return dip_dir  # 每一行是 [dip, strike]

    starttime = time.perf_counter()

    # calculate dip dir with numpy tensor
    np_clusters_normal = np.asarray([cluster.normal for cluster in clusters.clusters])
    np_dip_dir = npget_dip_dir(np_clusters_normal)

    discontinuitys = Discontinuity.Discontinuitys()
    for idx, cluster in enumerate(clusters.clusters):
        disc = Discontinuity.Discontinuity.from_cluster(cluster)
        disc.dip = np_dip_dir[idx, 0]
        disc.strike = np_dip_dir[idx, 1]
        disc.type = 'free surface'
        discontinuitys.add(disc)

    print(f'[time cost]{format_seconds(time.perf_counter() - starttime)} — create discontinuitys from clusters.')
    return discontinuitys


def format_seconds(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h} h {m} min {s:.2f} sec"


###################################################
###################################################
###################################################
def get_cluster_id(cluster_pointcloud):
    cluster_id_by_key = {}
    cluster_key_by_id = {}
    for id, (key, point) in enumerate(cluster_pointcloud.items()):
        cluster_id_by_key[key] = id
        cluster_key_by_id[id] = key

    # with open(save_path_1, "wb") as f:
    #     pickle.dump(cluster_key_to_ids, f)
    #
    # with open(save_path_2, "wb") as f:
    #     pickle.dump(cluster_ids_to_key, f)

    return cluster_id_by_key, cluster_key_by_id


def get_cluster_planeparas(data, cluster_point, save_path):
    cluster_planeparas = {}
    for key, point in cluster_point.items():
        cluster_planeparas[key] = data[point[0], 5:9]

    with open(save_path, "wb") as f:
        pickle.dump(cluster_planeparas, f)

    return cluster_planeparas


def get_plane_params(data, cluster_point, js_val, cl_val):
    # 找到所有匹配的索引
    indices = cluster_point.get((js_val, cl_val), [])
    if indices:
        i = indices[0]  # 取第一个匹配索引
        return data[i, 5:9]  # 第6-9列为 a, b, c, d
    else:
        return None


def get_strike_dip(A, B, C):
    # 单位化法向量
    norm = np.sqrt(A ** 2 + B ** 2 + C ** 2)
    a, b, c = A / norm, B / norm, C / norm

    # 倾角（Dip）
    dip = np.degrees(np.arccos(abs(c)))  # 注意取abs保证正值

    # 倾向（Strike），注意 atan2(-B, A)
    strike = np.degrees(np.arctan2(-b, a))
    if strike < 0:
        strike += 360

    return strike, dip


def get_trace_plane(cluster_point: dict, dip_dict: dict, save_path):
    """
    给定三维点及其法向平面参数，将点投影至平面后，使用“两次最远点搜索”法找到trace的两个端点。

    :param cluster_point : dict，键为(js, cl)，值为点索引列表
    :param dip_dict       : dict，包含法向量信息（A,B,C）
    :param save_path      : 路径，保存trace_dict结果
    :return: trace_dict : dict，键为(js, cl)，值为字典，含长度和端点坐标
            trace_dict[(js, cl)] = {
            'length': max_len,
            'start': coord_start.tolist(),
            'end': coord_end.tolist(),
            'start_idx': int(idx_start),
            'end_idx': int(idx_end)
        }
    """

    def project_points_to_plane(points, normal):
        """
        将三维点投影到给定法向量定义的平面上
        返回投影后的二维坐标和平面局部坐标系基向量（u, v）
        """
        normal = normal / np.linalg.norm(normal)
        # 找一个不平行于法向的向量构造局部平面坐标系
        arbitrary = np.array([1, 0, 0]) if abs(normal[0]) < 0.9 else np.array([0, 1, 0])
        u = np.cross(normal, arbitrary)
        u /= np.linalg.norm(u)
        v = np.cross(normal, u)
        v /= np.linalg.norm(v)
        projected_2d = np.dot(points, np.vstack([u, v]).T)
        return projected_2d, u, v

    def double_farest_search(projected_2d):
        center = projected_2d.mean(axis=0)
        dists_to_center = np.linalg.norm(projected_2d - center, axis=1)
        idx1 = np.argmax(dists_to_center)  # 边缘点1在 projected_2d 中的索引

        dists_to_idx1 = np.linalg.norm(projected_2d - projected_2d[idx1], axis=1)
        idx2 = np.argmax(dists_to_idx1)  # 边缘点2

        # 计算距离
        max_len = np.max(dists_to_idx1)

        idx_start = point_indices[idx1]
        idx_end = point_indices[idx2]
        return max_len, idx_start, idx_end

    trace_dict = {}
    for key, point_indices in cluster_point.items():
        if key not in dip_dict:
            continue
        A_nol, B_nol, C_nol = dip_dict[key][2:5]
        normal = np.array([A_nol, B_nol, C_nol])
        points = data[point_indices, 0:3]  # 未知原因导致基于point_indices提取的points中都是同一个点，可能是多个点都是同一个坐标

        # print(points)
        # 将点投影到对应平面
        projected_2d, u, v = project_points_to_plane(points, normal)

        if len(projected_2d) < 2:
            print('无法计算距离')
            continue  # 无法计算距离

        # 使用“两次最远点搜索”法找到trace的两个端点
        max_len, idx_start, idx_end = double_farest_search(projected_2d)
        if max_len == 0:
            # print(f'max_len:{max_len}       {point_indices}')
            continue
            # print(point_indices)
            # print(points)
            # print(u, v)
            # print(projected_2d)
        if max_len > 1:
            print(f'max_len:{max_len}')

        coord_start = data[idx_start, 0:3]
        coord_end = data[idx_end, 0:3]

        trace_dict[key] = {
            'length': max_len,
            'start': coord_start.tolist(),
            'end': coord_end.tolist(),
            'start_idx': int(idx_start),
            'end_idx': int(idx_end)
        }

    with open(save_path, "wb") as f:
        pickle.dump(trace_dict, f)

    return trace_dict


# ================================export
def write_ply_with_edges(filename, points, edges):
    """
    自定义写入 PLY 文件，包含 vertex 和 edge（line）

    Parameters
    ----------
    filename : str
        输出 ply 文件名
    points : (N, 3) np.ndarray
        顶点数组，float32
    edges : (M, 2) np.ndarray
        每条线由两个点索引组成，int32
    """
    num_vertices = points.shape[0]
    num_edges = edges.shape[0]

    with open(filename, 'wb') as f:
        # ===== 写入 PLY 头部 =====
        header = f"""ply
format binary_little_endian 1.0
element vertex {num_vertices}
property float x
property float y
property float z
element edge {num_edges}
property int vertex1
property int vertex2
end_header
"""
        f.write(header.encode('utf-8'))

        # ===== 写入 vertex 坐标数据 (float32) =====
        for pt in points:
            f.write(struct.pack('<fff', *pt))

        # ===== 写入 edge 数据（每条线是两个顶点索引） =====
        for edge in edges:
            f.write(struct.pack('<ii', *edge))


def export_trace_to_ply(trace_dict, save_path):
    """
    将 trace_dict 中的每条迹线（start, end）导出为包含 line 类型的 PLY 文件

    Parameters
    ----------
    trace_dict : dict
        每条迹线包含 'start', 'end' 坐标
    filename : str
        输出 ply 文件路径
    """
    points = []
    edges = []

    for trace in trace_dict.values():
        start = trace['start']
        end = trace['end']
        idx_start = len(points)
        idx_end = idx_start + 1
        points.append(start)
        points.append(end)
        edges.append([idx_start, idx_end])

    points = np.array(points, dtype=np.float64)
    edges = np.array(edges, dtype=np.int32)

    write_ply_with_edges(save_path, points, edges)
