import math
import time
from scipy.spatial import cKDTree as KDTree  # 替换 sklearn 的 KDTree
import networkx as nx
from multiprocessing import Pool, cpu_count
from itertools import combinations
from multiprocessing import Pool

import itertools
from collections import defaultdict
import multiprocessing
import numpy as np
from src import Discontinuity
from src import Rockblock
from tqdm import tqdm
from src import PointCloud
from scipy.spatial.distance import cdist
from CGAL import CGAL_Kernel
from CGAL.CGAL_Kernel import Point_3
from CGAL.CGAL_Kernel import Segment_3
from CGAL.CGAL_Kernel import Object


def analysis_rockblock_ellipdisk(discontinuitys: Discontinuity.Discontinuitys,
                                 extention=1.5, pool_size=16, max_memory=32):
    '''

    :param discontinuitys:
    :param extention: 用于控制椭圆盘的缩放比例
    :return:
    '''
    starttime = time.perf_counter()

    datalist = discontinuitys.discontinuitys
    # 先用disk的长轴建立球体，判断所有球体之间的相交情况，只有相交的球体才去尝试计算disk之间的交线

    # 过滤invalid结构面
    valid_discs = []
    index_map = []  # 存储 valid_discs 中对应原始 datalist 的索引
    for i, d in enumerate(datalist):
        if d.disc_center is not None and d.ellip_a is not None:
            valid_discs.append(d)
            index_map.append(i)

    # 构建球体数组 (N, 4) # balls = np.array([[x, y, z, r], ...])  # shape: (N, 4)，中心坐标+半径
    balls = np.asarray([[*d.disc_center, d.ellip_a * extention] for d in valid_discs], dtype=np.float64)

    # 通过球体的球心和半径寻找相交球对
    pairs = ball_neighbour_search(balls)

    # 从pairs返回discontinuity类对象对
    discontinuity_pairs = [(datalist[index_map[i]], datalist[index_map[j]]) for i, j in pairs]

    # 使用 NumPy 向量化实现两个结构面（Discontinuity）之间交线的方向向量快速求解;注意这里面可能存在共面或近乎共面的情况
    line_dirs, points, coplanar_masks = intersect_plane(discontinuity_pairs)

    # 采用并行运算来求解有限元交线段
    segments = multiprocess_discontinuity_intersection(discontinuity_pairs, line_dirs, points, coplanar_masks,
                                                       pool_size=pool_size)

    # 成对求解segments之间的交点node，注意浮点运算的截尾误差
    # nodes 是[(i, j, pt),...]
    nodes = parallel_segment_intersections(segments, tol=1e-6, pool_size=pool_size)

    # 聚合node为unique node，因为一个node实际上至少对应了3组segment pairs
    unodes_coord, unodes_by_disc = aggregate_nodes_with_tolerance(nodes, segments, tol=1e-6)

    # 构建有向图网络
    surface_graph = extract_surface_loops(unodes_coord, unodes_by_disc, segments, pool_size=None)

    # 采用面-面邻接法 + 空间遍历法构建块体
    Rockblocks = generate_block(surface_graph)

    print(f'[time cost]{format_seconds(time.perf_counter() - starttime)} — analysis rockblock from elliptical disk.')
    return Rockblocks


def multiprocess_discontinuity_intersection(discontinuity_pairs, line_dirs, points, coplanar_masks, pool_size=16):
    """
    使用多进程并行计算结构面椭球/椭圆盘之间的交线信息。

    :param discontinuity_pairs: List[Tuple[Discontinuity, Discontinuity]]
    :param line_dirs: ndarray, shape (m, 3)，每对结构面的交线方向
    :param points: ndarray, shape (m, 3)，每条交线上的一点
    :param coplanar_masks: ndarray, shape (m,)，共面掩码
    :param pool_size: int，多进程数量
    :return: List of intersection segments
    """
    starttime = time.perf_counter()
    pool = multiprocessing.Pool(processes=pool_size)

    # 构造组合数据：每一项是一个 tuple 包含所需数据
    datalist = list(zip(discontinuity_pairs, line_dirs, points, coplanar_masks))

    # 使用 list 切分方式（替代 np.array_split）
    def chunk_list(lst, n_chunks):
        chunk_size = math.ceil(len(lst) / n_chunks)
        return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

    batches = chunk_list(datalist, pool_size)

    print('pool_size:', pool_size)
    print('batch_size:', len(batches[0]))
    print('batch_number:', len(batches))

    # For each batch, a process pool is started
    results = []
    for batch in batches:
        result = pool.starmap_async(intersect_ellipdisk,
                                    [tuple_data for tuple_data in batch],
                                    error_callback=print_error)
        results.append(result)

    # Wait for all process pools to finish executing
    print('Waiting for all subprocesses done...')
    for result in results:
        result.wait()

    # 获取所有子进程返回的结果（二维列表），再拉平成一维
    true_results = [r.get() for r in results]  # => List of List
    segments = [item for sublist in true_results for item in sublist]

    # Closing the process pool
    pool.close()
    pool.join()
    print(
        f'[time cost]{format_seconds(time.perf_counter() - starttime)} — calculate intersections of discontinuity disks.')
    return segments


def intersect_ellipdisk(tuple_data):
    """
    计算两个椭圆盘结构面之间的交线与两个椭圆盘的交点（即线段两端点）

    :param tuple_data: ((disc1, disc2), line_dir, point, is_coplanar)
    :return: Rockblock.Segment(pt1, pt2,surface_ids=(id1, id2)) 若无交点则为 [None, None]
    """

    def intersect_line_with_ellipdisc(disc, point_on_line, line_dir):
        """
        计算一条空间直线与椭圆盘结构面的交点（最多2个）

        :param disc: 椭圆盘结构面对象，需具有 projections_uv、centroid、ellip_a、ellip_b 属性
        :param point_on_line: 空间直线上的一点 (3,)
        :param line_dir: 空间直线的方向向量 (3,)
        :return: None 或 (pt1, pt2) 两个交点
        """
        # 读取椭圆盘数据，并以椭圆盘构建局部坐标系
        long_axis_vertex = disc.long_axis_vertex
        short_axis_vertex = disc.short_axis_vertex
        origin = disc.disc_center  # 局部三维原点
        a = disc.ellip_a
        b = disc.ellip_b
        u = long_axis_vertex / a  # 长轴u 三维单位向量
        v = short_axis_vertex / b  # 短轴v 三维单位向量

        # 直线映射到椭圆盘所在二维平面
        rel = point_on_line - origin
        x0 = np.dot(rel, u)  # 将 rel 向量分别投影到 u、v 基底上，得到该点在椭圆盘局部坐标系中的二维坐标 (x0, y0)
        y0 = np.dot(rel, v)
        dx = np.dot(line_dir, u)  # 将直线方向向量 line_dir 投影到 u 和 v 方向上。得到直线在椭圆盘二维平面中的方向向量 (dx, dy)
        dy = np.dot(line_dir, v)

        # 求解椭圆方程下的二次方程：A t^2 + B t + C = 0
        x_para1, y_para1 = dx / a, dy / b
        x_para2, y_para2 = x0 / a, y0 / b
        A = x_para1 * x_para1 + y_para1 * y_para1
        B = 2 * (x_para1 * x_para2 + y_para1 * y_para2)
        C = x_para2 * x_para2 + y_para2 * y_para2

        Delta = B ** 2 - 4 * A * C
        if Delta <= 0:
            return None  # 无交点或只有1个交点

        sqrt_D = np.sqrt(Delta)
        t1 = (-B - sqrt_D) / (2 * A)
        t2 = (-B + sqrt_D) / (2 * A)
        # pt1 = point_on_line + t1 * line_dir
        # pt2 = point_on_line + t2 * line_dir
        return (min(t1, t2), max(t1, t2))  # 保证顺序：小值在前

    # 交线（空间直线）的方向向量
    pt_none = [0, 0, 0]
    (disc1, disc2), line_dir, point_on_line, is_coplanar = tuple_data

    # 判断交线是否共面
    if is_coplanar:
        # 说明几乎共面，可以视作无交线或特殊处理
        return Rockblock.Segment(pt_none, pt_none, line_dir, None)

    # 将line_dir分别投影到disc1, disc2上计算截线段
    seg1_t = intersect_line_with_ellipdisc(disc1, point_on_line, line_dir)
    seg2_t = intersect_line_with_ellipdisc(disc2, point_on_line, line_dir)

    if seg1_t is None or seg1_t is None:
        return Rockblock.Segment(pt_none, pt_none, line_dir, None)

    # 将两个三维点段 seg1, seg2 映射到 line_dir 上的参数 t 值段
    # 直线表示为 p(t) = point_on_line + t * line_dir
    t1_min, t1_max = seg1_t
    t2_min, t2_max = seg2_t

    # 求两个区间的交集 [t_min, t_max]
    t_min = max(t1_min, t2_min)
    t_max = min(t1_max, t2_max)

    # 为增强数值稳健性，防止由于浮点误差导致交线极短的问题, 设置为相对误差
    tol = 1e-8 * max(abs(t1_max - t1_min), abs(t2_max - t2_min))
    if t_max - t_min <= tol:
        return Rockblock.Segment(pt_none, pt_none, line_dir, None)  # 无交段

    # 计算交段的三维空间端点
    pt_start = point_on_line + t_min * line_dir
    pt_end = point_on_line + t_max * line_dir

    return Rockblock.Segment(pt_start, pt_end, line_dir, (disc1.cluster_id, disc2.cluster_id))


def ball_neighbour_search(balls):
    '''

    :param balls: np.array([[x, y, z, r], ...])
    :return:
    '''
    centers = balls[:, :3]
    radii = balls[:, 3]

    # 建立 KDTree 时间复杂度约 O(N log N)，适合上万规模
    tree = KDTree(centers)

    # 每个球搜索“可能相交”的近邻：搜索距离 = 最大可能半径之和
    max_radius = np.max(radii)
    pairs = set()
    for i in range(len(balls)):
        center_i = centers[i]
        radius_i = radii[i]
        # 搜索半径设为：r_i + max(r) ≈ 最坏情况
        # 逻辑：如果r_i + max(r)内都没有其他球心的话，那么该球没有neighbors
        neighbors = tree.query_ball_point(center_i, r=radius_i + max_radius)
        for j in neighbors:
            if i < j:
                # 精确判断是否相交
                dist_ij = np.linalg.norm(centers[i] - centers[j])
                if dist_ij <= radii[i] + radii[j]:
                    pairs.add((i, j))

    return list(pairs)  # pairs = [(i, j), ...]  # 所有相交球体的索引对


def intersect_plane(discontinuity_pairs, coplanar_tol=1e-6):
    """
    批量计算多个结构面对之间的交线方向、交点及共面性判断。

    :param discontinuity_pairs: List[Tuple[Discontinuity, Discontinuity]]
    :param coplanar_tol: float, 判断是否共面的阈值
    :return:
        line_dirs: (m, 3) ndarray，每对平面的交线方向（若共面为0向量）
        points_on_lines: (m, 3) ndarray，交线上的一点（共面则为np.nan）
        coplanar_mask: (m,) ndarray，bool数组，表示是否共面
    """
    if len(discontinuity_pairs) > 10_000:
        print(f"[警告] 待计算的结构面组合数超过1万对：{len(discontinuity_pairs)}，可能造成内存爆炸。")

    n1s = np.asarray([pair[0].normal for pair in discontinuity_pairs], dtype=np.float64)  # (m, 3)
    n2s = np.asarray([pair[1].normal for pair in discontinuity_pairs], dtype=np.float64)  # (m, 3)
    p1s = np.asarray([pair[0].disc_center for pair in discontinuity_pairs], dtype=np.float64)  # (m, 3)
    p2s = np.asarray([pair[1].disc_center for pair in discontinuity_pairs], dtype=np.float64)  # (m, 3)
    assert n1s.shape == (len(discontinuity_pairs), 3)
    assert n2s.shape == (len(discontinuity_pairs), 3)
    assert p1s.shape == (len(discontinuity_pairs), 3)
    assert p2s.shape == (len(discontinuity_pairs), 3)

    # 交线方向向量（未归一化）
    raw_dirs = np.cross(n1s, n2s)  # (m, 3)
    assert raw_dirs.shape == (len(discontinuity_pairs), 3)
    norms = np.linalg.norm(raw_dirs, axis=1)  # (m)
    assert len(norms.shape) == 1

    # 共面检测：交线方向模长是否接近0
    coplanar_mask = norms < coplanar_tol
    line_dirs = np.zeros_like(raw_dirs)
    line_dirs[~coplanar_mask] = raw_dirs[~coplanar_mask] / norms[~coplanar_mask, None]  # 归一化后的方向
    assert raw_dirs.shape[1] == 3

    # 平面方程的 d = n·p
    d1s = np.einsum('ij,ij->i', n1s, p1s)
    d2s = np.einsum('ij,ij->i', n2s, p2s)

    # 初始化交点数组
    points_on_lines = np.full_like(n1s, np.nan)

    for i in range(len(discontinuity_pairs)):
        if coplanar_mask[i]:
            continue
        A = np.column_stack([n1s[i], n2s[i], line_dirs[i]])  # (3, 3)
        b = np.array([d1s[i], d2s[i], 0.0])
        try:
            x = np.linalg.solve(A, b)
            points_on_lines[i] = x
        except np.linalg.LinAlgError:
            # 奇异矩阵时处理为 nan
            coplanar_mask[i] = True
            points_on_lines[i] = np.nan
            line_dirs[i] = 0.0

    return line_dirs, points_on_lines, coplanar_mask


def intersect_segments(seg_a: Rockblock.Segment, seg_b: Rockblock.Segment, tol=1e-6):
    """
    判断两条 Segment 对象是否相交，支持容差，返回交点 np.ndarray(3,) 或 None。
    """
    # 判断是否为空
    if seg_a is None or seg_b is None:
        return None

    # CGAL 表示
    try:
        s1 = Segment_3(Point_3(*seg_a.p1), Point_3(*seg_a.p2))
        s2 = Segment_3(Point_3(*seg_b.p1), Point_3(*seg_b.p2))
        obj = CGAL_Kernel.intersection(s1, s2)
    except Exception:
        return None

    # 若无交点
    if obj is None:
        return None

    # 返回交点（Point_3）
    try:
        pt = obj.get_Point_3()
        return np.array([pt.x(), pt.y(), pt.z()], dtype=np.float64)
    except:
        # 若不是点交，可能是重合 segment，此时视为无交点
        return None


def parallel_segment_intersections(segments, tol=1e-6, pool_size=8):
    def get_segment_aabbs(segments):
        """
        segments: List[Segment]
        返回各 segment 的 [xmin, ymin, zmin, xmax, ymax, zmax]
        """
        boxes = []
        for seg in segments:
            p1, p2 = seg.p1, seg.p2
            box = np.hstack([np.minimum(p1, p2), np.maximum(p1, p2)])
            boxes.append(box)
        return np.array(boxes)

    def aabb_intersect(a, b):
        return np.all(a[:3] <= b[3:]) and np.all(b[:3] <= a[3:])

    boxes = get_segment_aabbs(segments)
    candidate_pairs = [(i, j) for i, j in combinations(range(len(segments)), 2)
                       if aabb_intersect(boxes[i], boxes[j])]

    def task(args):
        i, j = args
        pt = intersect_segments(segments[i], segments[j], tol)
        if pt is not None:
            return (i, j, pt)
        else:
            return None

    with Pool(pool_size) as pool:
        results = pool.map(task, candidate_pairs)

    return [r for r in results if r is not None]  # 结果格式: [(i, j, pt),...]


def aggregate_nodes_with_tolerance(nodes, segments, tol=1e-6):
    """
    聚合交点：将距离小于 tol 的交点聚为同一个点。

    输入：
        nodes: List of (i, j, pt) 三元组，pt 是 ndarray(3,)
        segments: 原始 Segment 列表，用于回查 surface_id 信息
        tol: 距离容差

    返回：
        unodes_coord: ndarray(N, 3)，唯一聚合点坐标
        unodes_by_disc: Dict[int, List[(i, j, idx)]]
                          将原始边(i, j)映射为聚合点索引，并按 surface_id 组织
    """
    nodes_coord = np.array([pt for _, _, pt in nodes])
    tree = KDTree(nodes_coord)

    # 获取每个点在 tol 半径内的所有点索引
    neighbors = tree.query_ball_point(nodes_coord, r=tol)

    # 使用并查集构造点的聚合组
    # 并查集（Union-Find）结构：用于将多个点根据距离容差（如空间点之间的距离小于 tol）聚合为若干个集合。
    # 它的作用是：高效地判断哪些点属于同一个“点簇”或“点团”，并支持动态合并
    parent = np.arange(len(nodes_coord))  # 生成一个整数数组，从 0 到 len(nodes_coord)-1

    def find(u):
        while parent[u] != u:
            parent[u] = parent[parent[u]]
            u = parent[u]
        return u

    def union(u, v):
        pu, pv = find(u), find(v)
        if pu != pv:
            parent[pu] = pv

    for i, group in enumerate(neighbors):
        for j in group:
            union(i, j)

    # 生成最终唯一点及映射
    cluster_map = {}
    unodes_coord = []  # 记录唯一点upt的坐标值
    node_unode_indices = []  # 以node的索引 查询唯一点upt的索引

    for k in range(len(nodes_coord)):
        root = find(k)
        if root not in cluster_map:
            cluster_map[root] = len(unodes_coord)
            unodes_coord.append(nodes_coord[root])
        node_unode_indices.append(cluster_map[root])

    # 构建边图：按结构面组织
    unodes_by_disc = defaultdict(list)
    for (i, j, _), idx in zip(nodes, node_unode_indices):
        seg_i = segments[i]
        seg_j = segments[j]
        common_surfaces = set(seg_i.surface_ids) & set(seg_j.surface_ids)
        for cluster_id in common_surfaces:
            # 存储以cluster_id的列表字典，每个列表中包含了node对应的唯一点索引[为什么只记录1个点？没有edge信息啊，不是所有点都相互连接]
            unodes_by_disc[cluster_id].append((i, j, idx))  # (seg_i_idx, seg_j_idx, upt_idx)

    return np.array(unodes_coord), unodes_by_disc


def extract_surface_loops(unodes_coord, unodes_by_disc, segments, pool_size=None):
    '''

    :param segments:List[Segment]
    :param nodes:[(segment_i, segment_j, pt),...]   pt是array[pt.x(), pt.y(), pt.z()]
    :param tol:
    :param pool_size:
    :return:
        point_coords: 所有唯一聚合交点 np.ndarray 列表
        surface_loops: Dict[surface_id → List[Loop]]，每个 loop 是点的坐标列表
    '''

    def build_graph_and_find_cycles(args):
        cluster_id, unodes_idx_list, segments, point_coords = args
        g = nx.Graph()
        seg_unodes = defaultdict(list)  # segment_id -> list of (idx, coord)

        # Step 1: 将 unodes 按 segment 聚集
        for seg_i, seg_j, idx in unodes_idx_list:
            for s in [seg_i, seg_j]:
                seg_unodes[s].append((idx, point_coords[idx]))

        # Step 2: 对每条 segment 上的点排序并连边
        for seg_id, pts in seg_unodes.items():
            if len(pts) < 2:
                continue
            # 获取当前 segment 的方向
            seg = segments[seg_id]
            start, end = seg.p1, seg.p2  # 假设 segment 有 start/end 属性
            dir_vec = seg.dir

            # 按投影距离排序
            pts.sort(key=lambda x: np.dot(x[1] - start, dir_vec))  # (idx, coord)

            # 连续两两相连
            for (idx1, _), (idx2, _) in zip(pts[:-1], pts[1:]):
                g.add_edge(idx1, idx2)

        # Step 3: 提取闭环
        cycles = nx.cycle_basis(g)
        loops = [[point_coords[idx] for idx in cycle] for cycle in cycles]
        return cluster_id, loops

    def build_graph_and_find_cycles_test1(args):
        cluster_id, unodes_idx_list, segments, point_coords = args
        g = nx.Graph()
        for i, j, unode_idx in unodes_idx_list:
            seg_i = segments[i]
            seg_j = segments[j]
            # 得到两个 segment 中关于该 surface 的边段（交点分布在 segment 上）
            for seg in [seg_i, seg_j]:
                if cluster_id not in seg.surface_ids:
                    continue
                # 连接 segment 上该 surface 的交点段
                # 收集disc上其他与seg_i或者seg_j有关的unode
                other_pts = []
                for node in unodes_idx_list:
                    if node[2] != unode_idx and (node[0] == i or node[1] == i or node[0] == j or node[1] == j):
                        other_pts.append(node[2])
                # 将给定点unode_idx与其他点之间的边加到图中
                '''
                问题出在这里，以某个节点为初始点，连接任何在其2条seg上的所有其他node会导致同一条seg上的node不是顺序连接，而是相互连接
                '''
                for other in other_pts:
                    g.add_edge(unode_idx, other)

        # 提取闭环（cycle basis）
        cycles = nx.cycle_basis(g)
        loops = [[point_coords[idx] for idx in cycle] for cycle in cycles]
        return cluster_id, loops

    # main
    if pool_size is None:
        pool_size = max(cpu_count() - 1, 1)

    args_list = [
        (cluster_id, unodes_idx_list, segments, unodes_coord)
        for cluster_id, unodes_idx_list in unodes_by_disc.items()
    ]

    with Pool(processes=pool_size) as pool:
        results = pool.map(build_graph_and_find_cycles, args_list)

    surface_loops = dict(results)
    return surface_loops


def generate_block(surface_graph):


def print_error(value):
    '''
    这个函数可以输出多进程中的报错，但是不会终止多进程
    '''
    print("error: ", value)


def format_seconds(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h} h {m} min {s:.2f} sec"
