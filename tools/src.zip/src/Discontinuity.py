import pickle
import numpy as np
from scipy.spatial import ConvexHull
import numpy as np
from scipy.optimize import leastsq
from sklearn.decomposition import PCA
import pyvista as pv
from shapely.geometry import MultiPoint
from shapely.ops import triangulate
from scipy.spatial import Delaunay
from src import Cluster
from shapely.geometry import Polygon, MultiLineString
import alphashape
from shapely.ops import triangulate
import numpy as np


class Discontinuity(Cluster.Cluster):
    def __init__(self, joint_id, joint_cluster_id, cluster_id, rock_points, plane_params):
        super().__init__(joint_id, joint_cluster_id, cluster_id, rock_points, plane_params)
        self.valid = self.valid  # 父类Cluster构造中已经计算
        self.centroid = self.centroid  # 父类Cluster已有
        self.normal = self.normal  # 父类Cluster已有

        # Discontinuity自己扩展的属性
        self.dip = None
        self.strike = None
        self.type = ''
        self.roughness = 0

        self.convexhull_vertex_index = None  # we can read projections and rock_pointcloud by this vertex_index
        self.convexhull_centroid_2d = None
        self.convexhull_centroid_3d = None
        self.convexhull_area = 0

        self.ashape_vertex_index = None
        self.ashape_centroid_2d = None
        self.ashape_centroid_3d = None
        self.ashape_area = 0
        self.ashape_alpha = None

        self.trace_type = None
        self.trace_vertex_index = None
        self.trace_length = None

        self.disc_type = None
        self.disc_center = None
        self.disc_radius = None
        self.disc_normal = self.normal
        self.ellip_a = None
        self.ellip_b = None
        self.long_axis_vertex = None
        self.short_axis_vertex = None
        self.ratio_axis = None
        self.calculate_time = 0

    @classmethod
    def from_cluster(cls, cluster_obj: Cluster.Cluster):
        return cls(
            joint_id=cluster_obj.joint_id,
            joint_cluster_id=cluster_obj.joint_cluster_id,
            cluster_id=cluster_obj.cluster_id,
            rock_points=cluster_obj.rock_points,
            plane_params=cluster_obj.plane_params
        )

    def get_convexhull(self):
        """
        获取 cluster.projections 中构成凸包的点的索引。
        :return: 索引列表（按逆时针排列）
        """
        projections = self.projections  # shape (N, 2)

        if projections.shape[0] < 3 or np.linalg.matrix_rank(projections) < 2:
            # 无法构成凸包，直接返回全部索引
            self.valid = False
            self.convexhull_vertex_index = list(range(projections.shape[0]))
            self.convexhull_area = 0.0
            self.convexhull_centroid_2d = np.mean(projections, axis=0)
            self.convexhull_centroid_3d = Discontinuity.project_2d_to_3d(self, self.convexhull_centroid_2d)
            return self.convexhull_vertex_index

        try:
            hull = ConvexHull(projections)
            vertex_indices = hull.vertices.tolist()  # 按逆时针顺序
            self.convexhull_vertex_index = vertex_indices

            # 面积
            self.convexhull_area = hull.volume  # 2D 中 volume 即 area
            if self.convexhull_area != 0:
                self.valid = True

            # 二维质心：使用多边形质心公式
            hull_pts = projections[vertex_indices]
            x = hull_pts[:, 0]
            y = hull_pts[:, 1]
            area = 0.0
            cx = 0.0
            cy = 0.0
            for i in range(len(hull_pts)):
                j = (i + 1) % len(hull_pts)
                cross = x[i] * y[j] - x[j] * y[i]
                area += cross
                cx += (x[i] + x[j]) * cross
                cy += (y[i] + y[j]) * cross
            area *= 0.5
            if abs(area) < 1e-10:
                centroid = np.mean(hull_pts, axis=0)
            else:
                cx /= (6.0 * area)
                cy /= (6.0 * area)
                centroid = np.array([cx, cy])
            self.convexhull_centroid_2d = centroid

            # 三维质心
            self.convexhull_centroid_3d = Discontinuity.project_2d_to_3d(self, centroid)

        except:
            # 无法构成凸包，直接返回全部索引
            self.valid = False
            self.convexhull_vertex_index = list(range(projections.shape[0]))
            self.convexhull_area = 0.0
            self.convexhull_centroid_2d = np.mean(projections, axis=0)
            self.convexhull_centroid_3d = Discontinuity.project_2d_to_3d(self, self.convexhull_centroid_2d)
            return self.convexhull_vertex_index

    def get_alpha_shape(self, alpha=1.0):
        '''
        加速方式：单独并行运算
        获取 cluster.projections 中通过 Alpha Shape 构成边界的点的索引。
        :param alpha: 可选，形状参数；为 None 时自动估计。
        :return: 点索引列表（按逆时针排列）
        '''
        projections = self.projections  # shape (N, 2)

        if projections.shape[0] < 4:
            self.valid = False
            self.ashape_vertex_index = list(range(projections.shape[0]))
            self.ashape_area = 0.0
            self.ashape_centroid_2d = np.mean(projections, axis=0)
            self.ashape_centroid_3d = Discontinuity.project_2d_to_3d(self, self.ashape_centroid_2d)
            return self.ashape_vertex_index

        # 构建 alpha shape 多边形
        alpha_shape = alphashape.alphashape(projections, alpha)

        # 如果为 MultiPolygon，仅取最大面积那个
        if alpha_shape.geom_type == 'MultiPolygon':
            alpha_shape = max(alpha_shape.geoms, key=lambda p: p.area)

        # 点顺序索引：找到构成边界的点坐标并匹配原始索引
        boundary_coords = np.array(alpha_shape.exterior.coords[:-1])  # 移除重复起点
        vertex_indices = []
        for coord in boundary_coords:
            dists = np.linalg.norm(projections - coord, axis=1)
            idx = np.argmin(dists)
            vertex_indices.append(idx)

        self.ashape_vertex_index = vertex_indices

        # 面积
        self.ashape_area = alpha_shape.area
        if self.ashape_area != 0:
            self.valid = True

        # 质心（二维）
        centroid = np.array(alpha_shape.centroid.coords[0])
        self.ashape_centroid_2d = centroid

        # 质心（三维）
        self.ashape_centroid_3d = Discontinuity.project_2d_to_3d(self, centroid)
        self.ashape_alpha = alpha

    def get_trace_segment_from_edges(self):
        '''
        从边界点中寻找最远的一对点，作为迹线（trace segment）
        :return: None（结果保存在 self.trace_vertex_index, self.trace_length 等属性中）
        '''
        if self.convexhull_vertex_index is not None and self.convexhull_area != 0:
            vertex_indices = self.convexhull_vertex_index
        elif self.ashape_vertex_index is not None and self.ashape_area != 0:
            vertex_indices = self.ashape_vertex_index
        else:
            raise Exception('No valid edge boundary available to infer trace.')

        # 边界点坐标（二维）
        polygon_vertexs = self.projections[vertex_indices]  # shape (M, 2)

        # 使用 numpy 计算欧氏距离矩阵
        diffs = polygon_vertexs[:, np.newaxis, :] - polygon_vertexs[np.newaxis, :, :]  # shape (M, M, 2)
        dist_matrix = np.linalg.norm(diffs, axis=-1)  # shape (M, M)

        # 找到最大距离对应的点对索引
        i, j = np.unravel_index(np.argmax(dist_matrix), dist_matrix.shape)

        # 映射回原始 projections 的索引
        point_id1 = vertex_indices[i]
        point_id2 = vertex_indices[j]

        # 保存结果
        self.trace_vertex_index = [point_id1, point_id2]
        self.trace_type = 'trace from edges'

    def get_trace_segment_from_farthest2(self):
        '''

        :return:
        '''
        center = self.projections.mean(axis=0)
        dists_to_center = np.linalg.norm(self.projections - center, axis=1)
        point_id1 = np.argmax(dists_to_center)  # 边缘点1在 projected_2d 中的索引

        dists_to_idx1 = np.linalg.norm(self.projections - self.projections[point_id1], axis=1)
        point_id2 = np.argmax(dists_to_idx1)  # 边缘点2

        self.trace_vertex_index = [point_id1, point_id2]
        self.trace_type = 'trace from farthest'

    def get_trace_length(self):
        """
        根据 trace_vertex_index 中的两个点索引，从 rock_points 中获取坐标并计算三维迹线长度。
        """
        point_id1, point_id2 = self.trace_vertex_index
        p1 = self.rock_points.points[point_id1].coord
        p2 = self.rock_points.points[point_id2].coord
        self.trace_length = np.linalg.norm(p1 - p2)
        # 额外的检验
        if self.trace_length == 0:
            self.valid = False

    def get_disc_circle(self):
        """
        由迹线端点和结构面法向计算圆盘参数，包括中心、法向、半径等。
        """
        idx1, idx2 = self.trace_vertex_index
        p1 = self.rock_points.points[idx1].coord
        p2 = self.rock_points.points[idx2].coord

        self.disc_type = 'circle'
        self.disc_center = 0.5 * (p1 + p2)
        self.disc_radius = self.trace_length * 0.5

    def get_disc_elliptical(self):
        '''
        加速方式：单独并行运算
        :return:
        '''

        def rotate_points(points, center, theta):
            """
            向量化旋转所有点
            :param points: shape (n,2)的numpy数组
            :param center: 旋转中心 (cx, cy)
            :param theta: 旋转弧度（逆时针）
            :return: 旋转后的坐标数组
            """
            translated = points - center
            cos_theta = np.cos(theta)
            sin_theta = np.sin(theta)
            # 构建旋转矩阵
            rot_matrix = np.array([
                [cos_theta, sin_theta],
                [-sin_theta, cos_theta]
            ])
            # 矩阵乘法实现旋转
            rotated = translated @ rot_matrix.T
            return rotated + center

        if not self.valid:
            return None

        # get polygon vertexs in projection plane
        if self.convexhull_vertex_index != None:
            polygon_vertexs = self.projections[self.convexhull_vertex_index]
        elif self.ashape_vertex_index != None:
            polygon_vertexs = self.projections[self.ashape_vertex_index]
        else:
            raise Exception('Build polygon for point cloud first!')

        # get trace segments
        point_id1, point_id2 = self.trace_vertex_index
        point_3d1 = self.rock_points.points[point_id1].coord
        point_3d2 = self.rock_points.points[point_id2].coord
        point_2d1 = self.project_3d_to_2d(point_3d1)
        point_2d2 = self.project_3d_to_2d(point_3d2)

        # get elliptical centroid and long_axis
        ellp_centroid_2d = (point_2d2 + point_2d1) * 0.5
        ellp_centroid_3d = (point_3d2 + point_3d1) * 0.5

        # rotate polygon
        # 计算旋转角度（使迹线平行u轴）
        delta_2d = point_2d2 - point_2d1
        theta = np.arctan2(delta_2d[1], delta_2d[0])  # 原方向角度
        polygon_vertexs_rotated = rotate_points(polygon_vertexs, ellp_centroid_2d, theta)

        # find v_max and v_min of polygon
        v_coords = polygon_vertexs_rotated[:, 1]
        v_up = np.max(v_coords)
        v_low = np.min(v_coords)
        v_trace = ellp_centroid_2d[1]  # 旋转后的中心点v坐标保持不变

        # calculate the max distance to trace line, to be the short_axis of elliptical
        short_axis_length = max(v_up - v_trace, v_trace - v_low)

        # 长短轴端点（在2D平面中）
        u_2d = np.array([1.0, 0.0])  # 长轴方向
        v_2d = np.array([0.0, 1.0])  # 短轴方向
        long_axis_end_2d = ellp_centroid_2d + self.trace_length * 0.5 * u_2d
        short_axis_end_2d = ellp_centroid_2d + short_axis_length * v_2d

        # 旋转回原始方向（逆旋转）
        long_axis_end_2d_rot = rotate_points(np.array([long_axis_end_2d]), ellp_centroid_2d, -theta)[0]
        short_axis_end_2d_rot = rotate_points(np.array([short_axis_end_2d]), ellp_centroid_2d, -theta)[0]

        # 投影回三维空间
        long_axis_vertex_3d = self.project_2d_to_3d(long_axis_end_2d_rot)
        short_axis_vertex_3d = self.project_2d_to_3d(short_axis_end_2d_rot)

        # return elliptical parameters
        self.disc_type = 'elliptical'
        self.disc_center = ellp_centroid_3d
        self.disc_radius = None
        self.ellip_a = self.trace_length * 0.5
        self.ellip_b = short_axis_length
        self.long_axis_vertex = long_axis_vertex_3d
        self.short_axis_vertex = short_axis_vertex_3d
        self.ratio_axis = self.ellip_b / self.ellip_a

    def get_roughness(self, method='pca'):
        '''
        加速方式：单独并行运算
        :param method:
        :return:
        '''
        np_points = np.asarray([point.coord for point in self.rock_points.points])
        if method == 'pca':
            pca = PCA(n_components=3)
            pca.fit(np_points)
            normal = pca.components_[-1]
            residuals = (np_points - np_points.mean(0)) @ normal
            self.roughness = np.std(residuals)
        elif method == 'zrange':
            z_proj = np_points @ self.normal
            self.roughness = np.max(z_proj) - np.min(z_proj)

    def visualize(self, plotter=None, show=True):
        if plotter is None:
            plotter = pv.Plotter()
        np_points = np.asarray([point.coord for point in self.rock_points.points])
        plotter.add_points(np_points, color='blue', point_size=5)

        if self.ashape_vertex is not None:
            boundary = pv.lines_from_points(self.ashape_vertex, close=True)
            plotter.add_mesh(boundary, color='green', line_width=3)

        if self.disk_radius is not None:
            circle = pv.Circle(radius=self.disk_radius, resolution=100)
            circle.rotate_vector(self.normal, 0)
            circle.translate(self.disk_centroid)
            plotter.add_mesh(circle, color='red', opacity=0.5)

        if show:
            plotter.show()

    def print_all_attributes(self):
        """
        打印当前对象及其父类的所有属性及其对应值。
        """
        print(f"Attributes of {self.__class__.__name__}:")
        # 用集合去重
        printed_keys = set()
        for cls in self.__class__.__mro__:
            if cls is object:
                continue
            print(f"\nFrom class: {cls.__name__}")
            for key, value in cls.__dict__.items():
                # 跳过函数和类方法等
                if callable(value) or key.startswith('__'):
                    continue
            for key, value in self.__dict__.items():
                if key not in printed_keys:
                    print(f"  {key} = {value}")
                    printed_keys.add(key)


class Discontinuitys:
    def __init__(self):
        self.discontinuitys = []
        self.where = 'save_path'

    def add(self, disc: Discontinuity):
        self.discontinuitys.append(disc)

    def delete(self, cluster_id_list):
        self.discontinuitys = [dis for dis in self.discontinuitys if dis.cluster_id not in cluster_id_list]

    def export(self, path, format='pkl'):
        with open(path, 'wb') as f:
            pickle.dump(self.discontinuitys, f)

    def load(self, path):
        with open(path, 'rb') as f:
            self.discontinuitys = pickle.load(f)
